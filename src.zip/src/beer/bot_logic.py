from __future__ import annotations
from collections import deque
from typing import Deque, List, Optional, Set, Tuple
import random

Coord = Tuple[int, int]


class BotLogic:
    """Perfect 41-shot Hunt/Target strategy (no hangs, no wasted turns)."""

    def __init__(self, size: int = 10, *, seed: Optional[int] = None) -> None:
        self.size = size
        rnd = random.Random(seed)

        # Pre-shuffled parity list: 50 black then 50 white squares
        all_sq = [(r, c) for r in range(size) for c in range(size)]
        blacks = [(r, c) for r, c in all_sq if (r + c) % 2 == 0]
        whites = [(r, c) for r, c in all_sq if (r + c) % 2 == 1]
        rnd.shuffle(blacks); rnd.shuffle(whites)
        self.hunt_pool: Deque[Coord] = deque(blacks + whites)

        # Global state
        self.shots_taken: Set[Coord] = set()
        self.blocked: Set[Coord] = set()          # misses + halo

        # Target cluster
        self.hits: Set[Coord] = set()
        self.frontier: Deque[Coord] = deque()
        self.orientation: Optional[str] = None    # 'H' | 'V'

    # ---------------- helpers ---------------- #
    @staticmethod
    def coord_to_str(rc: Coord) -> str:
        return f"{chr(ord('A') + rc[0])}{rc[1] + 1}"

    def _enqueue(self, r: int, c: int) -> None:
        if (
            0 <= r < self.size and 0 <= c < self.size and
            (r, c) not in self.shots_taken and
            (r, c) not in self.blocked and
            (r, c) not in self.frontier
        ):
            self.frontier.append((r, c))

    # ------------- frontier builder ---------- #
    def _build_frontier(self) -> None:
        """Queue both ends *and* internal gaps along the discovered axis."""
        self.frontier.clear()
        if not self.hits:
            return

        rows = {r for r, _ in self.hits}
        cols = {c for _, c in self.hits}

        # Unknown axis → probe 4 neighbours of the first hit
        if len(rows) > 1 and len(cols) > 1:
            r0, c0 = next(iter(self.hits))
            for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                self._enqueue(r0 + dr, c0 + dc)
            return

        if len(rows) == 1:            # horizontal
            row = next(iter(rows))
            min_c, max_c = min(cols), max(cols)
            for c in range(min_c - 1, max_c + 2):
                self._enqueue(row, c)
            self.orientation = "H"
        else:                         # vertical
            col = next(iter(cols))
            min_r, max_r = min(rows), max(rows)
            for r in range(min_r - 1, max_r + 2):
                self._enqueue(r, col)
            self.orientation = "V"

    # --------------- shot choice ------------- #
    def choose_shot(self) -> Coord:
        # Target mode
        while self.hits:
            if not self.frontier:
                self._build_frontier()
                if not self.frontier:
                    # No legal frontier => treat ship as cleared (edge case)
                    self.hits.clear(); self.orientation = None
                    break
            while self.frontier:
                rc = self.frontier.popleft()
                if rc not in self.blocked and rc not in self.shots_taken:
                    return rc

        # Hunt mode
        while self.hunt_pool:
            rc = self.hunt_pool.popleft()
            if rc not in self.blocked and rc not in self.shots_taken:
                return rc

        # Absolute fallback (should never happen)
        for r in range(self.size):
            for c in range(self.size):
                if (r, c) not in self.shots_taken:
                    return (r, c)
        return (0, 0)

    # -------------- register result ---------- #
    def register_result(self, outcome: str, rc: Coord) -> None:
        outcome = outcome.upper()
        self.shots_taken.add(rc)

        if outcome == "MISS":
            self.blocked.add(rc)

        elif outcome == "HIT":
            self.hits.add(rc)

        elif outcome == "SUNK":
            self.hits.add(rc)
            # Block full 8-neighbour halo
            for r, c in self.hits:
                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        if dr or dc:
                            self.blocked.add((r + dr, c + dc))
            self.hits.clear()
            self.frontier.clear()
            self.orientation = None

    # -------------- hard reset --------------- #
    def reset(self) -> None:
        self.shots_taken.clear()
        self.blocked.clear()
        self.hits.clear()
        self.frontier.clear()
        self.orientation = None
