"""BEER Battleship package."""

__all__ = [
    "server",
    "client",
    "game",
]
